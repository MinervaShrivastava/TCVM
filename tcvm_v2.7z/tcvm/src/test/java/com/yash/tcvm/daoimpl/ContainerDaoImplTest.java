package com.yash.tcvm.daoimpl;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.yash.tcvm.dao.ContainerDAO;
import com.yash.tcvm.enumeration.Ingredient;
import com.yash.tcvm.exception.ContainerNotGivenException;
import com.yash.tcvm.exception.EmptyContainerException;
import com.yash.tcvm.exception.IngredientNotGivenException;
import com.yash.tcvm.model.Container;

public class ContainerDaoImplTest {

	private ContainerDAO containerDAO;
	@Before
	public void setUp() {
		containerDAO = new ContainerDAOImpl();
	}

	@Test(expected = ContainerNotGivenException.class)
	public void initializeContainer_ContainerNotGiven_ThrowsContainerNotGivenException() throws Exception {
		Container container = null;
		containerDAO.initializeContainer(container);
	}
	
	@Test(expected = EmptyContainerException.class)
	public void initializeContainer_ContainerDataNotGiven_ThrowsEmptyContainerException() throws Exception {
		Ingredient ingredient = null;
		Container container = new Container(ingredient, 0.00, 0.00);
		containerDAO.initializeContainer(container);
	}
	
	@Test
	public void initializeContainer_ContainerGiven_ShouldReturnTrueWhenContainerIsInitialized() {
		boolean  checkInitialization = containerDAO.initializeContainer(new Container(Ingredient.COFFEE, 2000, 2000));
		assertTrue(checkInitialization);
	}
	
	@Test
	public void getContainerByIngredient_IngredientGiven_ShouldReturnContainer() throws Exception {
		Ingredient ingredient = Ingredient.COFFEE;
		Container container = containerDAO.getContainerByIngredient(ingredient);
		assertEquals(ingredient, container.getIngredient());
	}
	
	@Test(expected = IngredientNotGivenException.class)
	public void getContainerByIngredient_IngredientNotGiven_throwsIngredientNotGivenException() {
		Ingredient ingredient = null;
		containerDAO.getContainerByIngredient(ingredient);
	}
	
	@Test
	public void getAllContainers_ShouldReturnListOfAllContainers() throws Exception {
		List<Container> containers =  containerDAO.getAllContainers();
		assertEquals(5, containers.size());
	}
	
	@Test
	public void updateContainer_ContainerGiven_ShouldReturnTrueWhenContainerIsUpdated() throws Exception {
		Container container = new Container(Ingredient.COFFEE, 2000, 2000);
		boolean containerUpdated = containerDAO.updateContainer(container);
		assertTrue(containerUpdated);
	}
}

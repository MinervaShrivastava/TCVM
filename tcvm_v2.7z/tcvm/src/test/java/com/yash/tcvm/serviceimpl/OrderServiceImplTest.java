package com.yash.tcvm.serviceimpl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.yash.tcvm.enumeration.Drink;
import com.yash.tcvm.exception.QuantityNotSpecifiedException;
import com.yash.tcvm.model.Order;
import com.yash.tcvm.service.OrderService;

public class OrderServiceImplTest {

	OrderService orderService;
	
	@Before
	public void setUp() {
		orderService = new OrderServiceImpl();
	}

	@Test
	public void orderDrink_QuantityGiven_ShouldReturnOrder() {
		
		int quantity = 2;
		
		Order order = orderService.orderDrink(Drink.TEA,quantity);
		assertEquals(Drink.TEA, order.getDrink());
	}

	@Test(expected = QuantityNotSpecifiedException.class)
	public void orderDrink_QuantityNotGiven_ThrowsQuantityNotSpecifiedException() throws Exception {
		int quantity = 0;
		orderService.orderDrink(Drink.COFFEE, quantity);
	}
}

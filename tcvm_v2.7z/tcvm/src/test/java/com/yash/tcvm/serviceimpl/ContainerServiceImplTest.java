package com.yash.tcvm.serviceimpl;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.yash.tcvm.dao.ContainerDAO;
import com.yash.tcvm.enumeration.Ingredient;
import com.yash.tcvm.model.Container;
import com.yash.tcvm.service.ContainerService;

public class ContainerServiceImplTest {

	@Mock
	private ContainerDAO containerDAO;
	
	private ContainerService containerService;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		containerService = new ContainerServiceImpl(containerDAO);
	}

	@Test
	public void getContainerByIngredient_IngredientGiven_ShouldReturnContainer() {
		Ingredient ingredient = Ingredient.COFFEE;
		when(containerDAO.getContainerByIngredient(ingredient)).thenReturn(new Container(Ingredient.COFFEE, 2000.00, 2000.00));
		Container container = containerService.getContainerByIngredient(ingredient);
		assertEquals(Ingredient.COFFEE, container.getIngredient());
	}
	
	@Test
	public void getContainers_ShouldReturnListOfContainers() {
		List<Container> expectedContainers = new ArrayList<Container>();
		expectedContainers.add(new Container(Ingredient.TEA, 2000.0, 2000.0));
		expectedContainers.add(new Container(Ingredient.SUGAR, 8000.0, 8000.0));
		expectedContainers.add(new Container(Ingredient.MILK, 10000, 10000));
		expectedContainers.add(new Container(Ingredient.COFFEE, 2000.0, 2000.0));
		expectedContainers.add(new Container(Ingredient.WATER, 15000, 15000));
		when(containerDAO.getAllContainers()).thenReturn(expectedContainers);
		List<Container> actaulContainers = containerService.getContainers();
		assertEquals(expectedContainers.size(), actaulContainers.size());
	}
	
	@Test
	public void updateContainer_ContainerGiven_ShouldReturnTrueWhenContainerIsUpdated() {
		Container container = new Container(Ingredient.COFFEE, 2000, 2000);
		when(containerDAO.updateContainer(container)).thenReturn(true);
		boolean containerUpdated = containerService.updateContainer(container);
		assertTrue(containerUpdated);
	}

}

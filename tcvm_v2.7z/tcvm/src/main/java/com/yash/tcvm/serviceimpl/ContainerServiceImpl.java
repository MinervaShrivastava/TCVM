package com.yash.tcvm.serviceimpl;

import java.util.List;

import com.yash.tcvm.dao.ContainerDAO;
import com.yash.tcvm.enumeration.Ingredient;
import com.yash.tcvm.model.Container;
import com.yash.tcvm.service.ContainerService;

public class ContainerServiceImpl implements ContainerService {

	private ContainerDAO containerDAO;
	
	public ContainerServiceImpl(ContainerDAO containerDAO) {
		this.containerDAO = containerDAO;
	}

	public Container getContainerByIngredient(Ingredient ingredient) {
		return containerDAO.getContainerByIngredient(ingredient);
	}

	public List<Container> getContainers() {
		return containerDAO.getAllContainers();
	}

	public boolean updateContainer(Container container) {
		return containerDAO.updateContainer(container);
	}
}

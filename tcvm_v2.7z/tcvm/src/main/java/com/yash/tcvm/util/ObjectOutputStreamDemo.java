package com.yash.tcvm.util;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class ObjectOutputStreamDemo extends ObjectOutputStream{

	public ObjectOutputStreamDemo(OutputStream out) throws IOException {
		super(out);
	}

}

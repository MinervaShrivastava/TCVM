package com.yash.tcvm.exception;

public class ContainerNotGivenException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ContainerNotGivenException(String errorMessage) {
		super(errorMessage);
	}
}

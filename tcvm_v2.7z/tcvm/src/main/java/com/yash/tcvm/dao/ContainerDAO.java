package com.yash.tcvm.dao;

import java.util.List;

import com.yash.tcvm.enumeration.Ingredient;
import com.yash.tcvm.model.Container;

public interface ContainerDAO {

	boolean initializeContainer(Container container);

	Container getContainerByIngredient(Ingredient ingredient);

	List<Container> getAllContainers();

	boolean updateContainer(Container container);

}

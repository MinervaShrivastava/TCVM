package com.yash.tcvm;

import java.util.Scanner;

import com.yash.tcvm.enumeration.Drink;
import com.yash.tcvm.model.Order;
import com.yash.tcvm.service.OrderService;
import com.yash.tcvm.serviceimpl.OrderServiceImpl;
import com.yash.tcvm.util.FileUtil;

public class ApplicationMenu {

	private Scanner input;
	
	public void getMenu() {
			
			input=new Scanner(System.in);
			FileUtil fileUtil = new FileUtil();
			OrderService orderService = new OrderServiceImpl();
			
			
			String choice;
			int menuChoice;
			do {
				fileUtil.readMenu("mainMenu.txt");
				menuChoice = input.nextInt();
				switch (menuChoice) {
				case 1:
					System.out.println("Making Coffee");
					System.out.println("Enter the no of cups : ");
					int cupsForCoffe = input.nextInt();
					Order orderForCoffe = orderService.orderDrink(Drink.COFFEE, cupsForCoffe);
					System.out.println("Your order is :"+orderForCoffe);
					break;

				case 2:
					System.out.println("Making Tea");
					System.out.println("Enter the no of cups : ");
					int cupsForTea = input.nextInt();
					Order orderForTea = orderService.orderDrink(Drink.TEA, cupsForTea);
					System.out.println("Your order is :"+orderForTea);
					break;
					
				case 3:
					System.out.println("Making Black Coffee");
					System.out.println("Enter the no of cups : ");
					int cupsForBlackCofee = input.nextInt();
					Order orderForBlackCoffee = orderService.orderDrink(Drink.TEA, cupsForBlackCofee);
					System.out.println("Your order is :"+orderForBlackCoffee);
					break;
					
				case 4:
					System.out.println("Making Black Tea");
					System.out.println("Enter the no of cups : ");
					int cupsForBlackTea = input.nextInt();
					Order orderForBlackTea = orderService.orderDrink(Drink.TEA, cupsForBlackTea);
					System.out.println("Your order is :"+orderForBlackTea);
					break;
					
				case 5:
					System.out.println("Check Total Sale");
	
					break;
					
				case 6:
					System.out.println("Chack Container Status");
					
					break;
					
				case 7:
					System.out.println("Reset container");
					
					break;
					
				case 8:
					System.out.println("Thank you for using the vending machine");
					System.exit(0);
					
				default:
					System.out.println("Please select a valid option : ");
					break;
				}
				System.out.println("Do you want to continue..?");
				choice=input.next();
			} while (choice.equalsIgnoreCase("Yes"));
			}
	}
package com.yash.tcvm.exception;

public class IngredientNotGivenException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public IngredientNotGivenException(String errorMessage) {
		super(errorMessage);
	}
}

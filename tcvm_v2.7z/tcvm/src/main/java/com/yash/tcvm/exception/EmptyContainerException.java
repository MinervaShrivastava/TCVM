package com.yash.tcvm.exception;

public class EmptyContainerException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EmptyContainerException(String errorMessage) {
		super(errorMessage);
	}
}

package com.yash.tcvm.serviceimpl;

import com.yash.tcvm.builder.BlackCoffeeBuilder;
import com.yash.tcvm.builder.BlackTeaBuilder;
import com.yash.tcvm.builder.CoffeeBuilder;
import com.yash.tcvm.builder.DrinkBuilder;
import com.yash.tcvm.builder.TeaBuilder;
import com.yash.tcvm.enumeration.Drink;
import com.yash.tcvm.exception.QuantityNotSpecifiedException;
import com.yash.tcvm.model.Order;
import com.yash.tcvm.service.OrderService;

public class OrderServiceImpl implements OrderService {

	public Order orderDrink(Drink drink, int quantity) {
		
		DrinkBuilder drinkBuilder = null;
		Order order = null;
		
		if(quantity <= 0)
			throw new QuantityNotSpecifiedException("quantity must be specified");
		
		switch (drink) {
		case TEA:
				drinkBuilder = TeaBuilder.getDrinkBuilder();
				order = drinkBuilder.prepareDrink(new Order(quantity, drink));
				break;
		case COFFEE:
			drinkBuilder = CoffeeBuilder.getDrinkBuilder();
			order = drinkBuilder.prepareDrink(new Order(quantity, drink));
			break;
		case BLACK_COFFEE:
			drinkBuilder = BlackCoffeeBuilder.getDrinkBuilder();
			order = drinkBuilder.prepareDrink(new Order(quantity, drink));
			break;
		case BLACK_TEA:
			drinkBuilder = BlackTeaBuilder.getDrinkBuilder();
			order = drinkBuilder.prepareDrink(new Order(quantity, drink));
			break;
		default:
			System.out.println("Please select a valid option");
			break;
		}
		
		return order;
		
	}

	

	

}

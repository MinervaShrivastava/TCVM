package com.yash.tcvm.config;

public interface DrinkConfigurer {

void configIngredientConsumption();
	
	void configIngredientWastage();
	
	void configDrinkType();
	
	void configDrinkRate();
	
}

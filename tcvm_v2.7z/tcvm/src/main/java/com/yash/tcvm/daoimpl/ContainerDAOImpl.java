package com.yash.tcvm.daoimpl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.google.gson.reflect.TypeToken;
import com.yash.tcvm.dao.ContainerDAO;
import com.yash.tcvm.enumeration.Ingredient;
import com.yash.tcvm.exception.ContainerNotGivenException;
import com.yash.tcvm.exception.EmptyContainerException;
import com.yash.tcvm.exception.IngredientNotFoundException;
import com.yash.tcvm.exception.IngredientNotGivenException;
import com.yash.tcvm.model.Container;
import com.yash.tcvm.util.FileUtil;
import com.yash.tcvm.util.JSONUtil;

public class ContainerDAOImpl implements ContainerDAO {
	
	private FileUtil fileUtil;
	Logger logger = Logger.getLogger("ContainerDAOImpl.class");
	
	public ContainerDAOImpl() {
		fileUtil = new FileUtil();
	}

	public boolean initializeContainer(Container container) {
		
		isContainerGiven(container);
		isContainerEmpty(container);
		String containerInString = JSONUtil.convertObjectToJSON(container);
		return fileUtil.writeInFile("containers", containerInString);
		
	}

	private void isContainerEmpty(Container container) {
		if(container.getIngredient() == null || container.getMaxCapacity() == 0.00 || container.getCurrentAvailability() == 0.00)
			throw new EmptyContainerException("Container should have some data");
	}

	private void isContainerGiven(Container container) {
		if(container == null)
			throw new ContainerNotGivenException("Container should be specified");
	}

	public Container getContainerByIngredient(Ingredient ingredient) {
		
		isIngredientGiven(ingredient);
		
		List<Container> containers = new ArrayList<Container>();
		containers = fileUtil.readFile("containers.json", new TypeToken<Container>() {}.getType());
		for (Container container : containers) {
			if(container.getIngredient().toString().equalsIgnoreCase(ingredient.toString())) {
				 logger.info("Found the container : "+container);
				return container;
			}
		}
		throw new IngredientNotFoundException("Your ingredient not found");
	}

	private void isIngredientGiven(Ingredient ingredient) {
		if(ingredient == null)
			throw new IngredientNotGivenException("Give an ingredient to search it's container");
	}

	public List<Container> getAllContainers() {
		return fileUtil.readFile("containers.json", new TypeToken<Container>() {}.getType());
	}

	public boolean updateContainer(Container container) {
		String containerInString = JSONUtil.convertObjectToJSON(container);
		return fileUtil.updateInFile("containers.json",containerInString);
	}

}

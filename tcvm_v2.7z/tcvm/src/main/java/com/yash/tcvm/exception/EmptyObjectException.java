package com.yash.tcvm.exception;

public class EmptyObjectException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EmptyObjectException(String errorMeassage) {
		super(errorMeassage);
	}
}

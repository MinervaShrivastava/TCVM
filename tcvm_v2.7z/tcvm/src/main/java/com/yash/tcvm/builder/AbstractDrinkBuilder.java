package com.yash.tcvm.builder;

import java.util.Map;
import com.yash.tcvm.config.AbstractDrinkConfigurer;
import com.yash.tcvm.config.DrinkConfigurer;
import com.yash.tcvm.enumeration.Ingredient;
import com.yash.tcvm.exception.ContainerUnderflowException;
import com.yash.tcvm.model.Container;
import com.yash.tcvm.model.Order;
import com.yash.tcvm.service.ContainerService;
import com.yash.tcvm.serviceimpl.ContainerServiceImpl;

public abstract class AbstractDrinkBuilder implements DrinkBuilder{

	DrinkConfigurer drinkConfigurer;
	ContainerService containerService;
	
	public void setDrinkConfigurer(DrinkConfigurer drinkConfigurer) {
		this.drinkConfigurer = drinkConfigurer;
	}

	public void setContainerService(ContainerServiceImpl containerServiceImpl) {
		this.containerService = containerServiceImpl;
	}

	public Order prepareDrink(Order order) throws ContainerUnderflowException {
		checkUnderFlow(order);
		updateContainers(order);
		order.setStatus(true);
		return order;
	}

	private void checkUnderFlow(Order order) {
		
		AbstractDrinkConfigurer abstractDrinkConfigurer = (AbstractDrinkConfigurer) drinkConfigurer;

		Map<Ingredient, Double> consumption = abstractDrinkConfigurer.getIngredientConsumption();
		Map<Ingredient, Double> wastage = abstractDrinkConfigurer.getIngredientWastage();

		for (Map.Entry<Ingredient, Double> entry : consumption.entrySet()) {

			double qtyWasted = wastage.get(entry.getKey());
			double qtyConsumed = entry.getValue();
			double qtyAvailableInContainer = containerService.getContainerByIngredient(entry.getKey())
					.getCurrentAvailability();
			int noOfCups = order.getQuantity();

			if (isUnderFlowCondition(qtyWasted, qtyConsumed, qtyAvailableInContainer, noOfCups)) {
				throw new ContainerUnderflowException(entry.getKey() + "Insufficient");
			}
		}
	}

	private boolean isUnderFlowCondition(double qtyWasted, double qtyConsumed, double qtyAvailableInContainer,
			int noOfCups) {
		return (noOfCups * (qtyConsumed + qtyWasted)) > qtyAvailableInContainer;
	}

	public void updateContainers(Order order) {

		AbstractDrinkConfigurer abstractDrinkConfigurer = (AbstractDrinkConfigurer) drinkConfigurer;

		Map<Ingredient, Double> consumption = abstractDrinkConfigurer.getIngredientConsumption();
		Map<Ingredient, Double> wastage = abstractDrinkConfigurer.getIngredientWastage();

		for (Map.Entry<Ingredient, Double> entry : consumption.entrySet()) {

			Container container = containerService.getContainerByIngredient(entry.getKey());

			double qtyWasted = wastage.get(entry.getKey());
			double qtyConsumed = entry.getValue();
			double qtyAvailableInContainer = container.getCurrentAvailability();
			int noOfCups = order.getQuantity();

			container.setCurrentAvailability(qtyAvailableInContainer - (noOfCups * (qtyConsumed + qtyWasted)));

			System.out.println("For container "+container.getIngredient()+" : Max capacity: " + container.getMaxCapacity() + " Current availability: "
					+ container.getCurrentAvailability());
			

		}

	}

}

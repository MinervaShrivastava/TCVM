package com.yash.tcvm.exception;

public class EmptyException extends Exception {

	private static final long serialVersionUID = 1L;

	public EmptyException(String message) {
		super(message);
	}

}

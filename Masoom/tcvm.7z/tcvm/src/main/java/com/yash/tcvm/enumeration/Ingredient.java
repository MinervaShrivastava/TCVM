package com.yash.tcvm.enumeration;

public enum Ingredient {

	SUGAR, TEA, COFFEE, MILK, WATER

}

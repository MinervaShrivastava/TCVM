package com.yash.tcvm.start;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Scanner;

import com.yash.tcvm.exception.EmptyException;
import com.yash.tcvm.literal.TCVMMenuConstants;
import com.yash.tcvm.util.FileUtil;

public class TCVM {

	Scanner scanner = new Scanner(System.in);

	private static TCVM tcvm = new TCVM();

	private TCVM() {

	}

	public static TCVM getTCVM() {
		return tcvm;
	}

	public void start() throws EmptyException {
		List<String> menuOptions = null;
		String choice = null;

		do {

			try {
				menuOptions = getMenu(TCVMMenuConstants.MENU_FILE_PATH);
			} catch (FileNotFoundException fileNotFoundException) {
				fileNotFoundException.printStackTrace();
			}

			for (String option : menuOptions) {
				System.out.println(option);
			}

			int selectedMenuOption = getUserSelectedMenuOption();

			getOperationToBePerformedBasedOnMenu(selectedMenuOption);

			System.out.println("Do you want to continue: y/n");
			scanner.nextLine();
			choice = scanner.nextLine();

		} while (choice.equalsIgnoreCase("y"));

	}

	public List<String> getMenu(String filePath) throws FileNotFoundException, EmptyException {

		checkIfFilePathIsNull(filePath);

		checkIfFilePathIsEmpty(filePath);

		File menuFile = new File(filePath);

		checkIfFileExists(menuFile);

		checkIfFileIsEmpty(menuFile);

		List<String> menuOptions = FileUtil.readFile(filePath);

		return menuOptions;
	}

	private void checkIfFileIsEmpty(File menuFile) throws EmptyException {
		if (menuFile.length() == 0) {
			throw new EmptyException("File cannot be empty");
		}
	}

	private void checkIfFileExists(File menuFile) throws FileNotFoundException {
		if (!menuFile.exists()) {
			throw new FileNotFoundException("File not found in given location");
		}
	}

	private void checkIfFilePathIsEmpty(String filePath) throws EmptyException {
		if (filePath.isEmpty()) {
			throw new EmptyException("File location cannot be empty");
		}
	}

	private void checkIfFilePathIsNull(String filePath) {
		if (filePath == null) {
			throw new NullPointerException("File location cannot be null");
		}
	}

	private int getUserSelectedMenuOption() {
		int selectedMenuOption = 0;
		System.out.println("Enter your choice: ");
		selectedMenuOption = scanner.nextInt();
		if (selectedMenuOption < 0 && selectedMenuOption > TCVMMenuConstants.MAX_NO_OF_MENU_OPTIONS) {
			System.out.println("selectedMenuOption: " + selectedMenuOption);
		}
		return selectedMenuOption;
	}

	private void getOperationToBePerformedBasedOnMenu(int selectedMenuOption) {
		switch (selectedMenuOption) {
		case TCVMMenuConstants.MAKE_COFFEE:
			makeCoffee();
			break;

		case TCVMMenuConstants.MAKE_TEA:
			makeTea();
			break;

		case TCVMMenuConstants.MAKE_BLACK_COFFEE:
			makeBlackCoffee();
			break;

		case TCVMMenuConstants.MAKE_BLACK_TEA:
			makeBlackTea();
			break;

		case TCVMMenuConstants.REFILL_CONTAINER:
			refillcontainer();
			break;

		case TCVMMenuConstants.CHECK_TOTAL_SALE:
			checkTotalSale();
			break;

		case TCVMMenuConstants.CONTAINER_STATUS:
			containerStatus();
			break;
			
		case TCVMMenuConstants.SHOW_REPORTS:
			showReports();
			break;

		case TCVMMenuConstants.EXIT_TCVM:
			System.out.println("Thank you for using TCVM..");
			System.exit(0);
			break;

		default:
			break;
		}
	}

	private void makeCoffee() {
		System.out.println("## PREPARING COFFEE ##");
	}

	private void makeTea() {
		System.out.println("## PREPARING TEA ##");
	}

	private void makeBlackCoffee() {
		System.out.println("## PREPARING BLACK COFFEE ##");
	}

	private void makeBlackTea() {
		System.out.println("## PREPARING BLACK TEA ##");
	}

	private void refillcontainer() {
		System.out.println("## REFILLING CONTAINER ##");
	}

	private void checkTotalSale() {
		System.out.println("## TOTAL SALE ##");
	}

	private void containerStatus() {
		System.out.println("## CONTAINERS STATUS ##");
	}
	
	private void showReports() {
		System.out.println("## DISPLAYING REPORTS ##");
	}

}

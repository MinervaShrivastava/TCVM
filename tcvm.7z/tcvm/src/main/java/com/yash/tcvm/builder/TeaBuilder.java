package com.yash.tcvm.builder;

import com.yash.tcvm.config.TeaConfiguration;
import com.yash.tcvm.enumeration.Drink;
import com.yash.tcvm.exception.ContainerUnderflowException;
import com.yash.tcvm.model.Order;

public class TeaBuilder extends AbstractDrinkBuilder{

	public TeaBuilder() {
		setDrinkConfigurer(TeaConfiguration.getDrinkConfigurer());
	}

	public static DrinkBuilder getDrinkBuilder() {
		return new TeaBuilder();
	}
	
	@Override
	public Order prepareDrink(Order order) throws ContainerUnderflowException {
		if (order.getDrink() == Drink.TEA) {
			return super.prepareDrink(order);
		} else {
			throw new IllegalArgumentException(
					"Wrong Drink Type, required " + Drink.TEA + " and found " + order.getDrink());
		}
	}

	

}

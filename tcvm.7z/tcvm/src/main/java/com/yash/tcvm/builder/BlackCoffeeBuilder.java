package com.yash.tcvm.builder;

import com.yash.tcvm.config.BlackCoffeeConfiguration;
import com.yash.tcvm.enumeration.Drink;
import com.yash.tcvm.exception.ContainerUnderflowException;
import com.yash.tcvm.model.Order;

public class BlackCoffeeBuilder extends AbstractDrinkBuilder{

	public BlackCoffeeBuilder() {
		setDrinkConfigurer(BlackCoffeeConfiguration.getDrinkConfigurer());
	}

	@Override
	public Order prepareDrink(Order order) throws ContainerUnderflowException {
		if (order.getDrink() == Drink.BLACK_COFFEE) {
			return super.prepareDrink(order);
		} else {
			throw new IllegalArgumentException(
					"Wrong Drink Type, required " + Drink.BLACK_COFFEE+ " and found " + order.getDrink());
		}
	}

	public static DrinkBuilder getDrinkBuilder() {
		return new BlackCoffeeBuilder();
	}
	
}

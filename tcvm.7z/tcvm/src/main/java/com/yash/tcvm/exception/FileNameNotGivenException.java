package com.yash.tcvm.exception;

public class FileNameNotGivenException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FileNameNotGivenException(String errorMessage) {
		super(errorMessage);
	}
}

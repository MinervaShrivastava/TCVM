package com.yash.tcvm.service;

import com.yash.tcvm.enumeration.Drink;
import com.yash.tcvm.model.Order;

public interface OrderService {

	Order orderDrink(Drink drink, int quantity);

}

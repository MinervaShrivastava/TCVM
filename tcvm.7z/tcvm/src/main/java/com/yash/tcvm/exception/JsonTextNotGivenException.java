package com.yash.tcvm.exception;

public class JsonTextNotGivenException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public JsonTextNotGivenException(String errorMessage) {
		super(errorMessage);
	}
}

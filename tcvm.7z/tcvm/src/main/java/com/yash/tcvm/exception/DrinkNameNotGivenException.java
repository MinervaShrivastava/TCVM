package com.yash.tcvm.exception;

public class DrinkNameNotGivenException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DrinkNameNotGivenException(String errorMessage) {
		super(errorMessage);
	}
}

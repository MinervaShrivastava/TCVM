package com.yash.tcvm.exception;

public class ContainerOverflowException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ContainerOverflowException(String errorMessage) {
		super(errorMessage);
	}
}

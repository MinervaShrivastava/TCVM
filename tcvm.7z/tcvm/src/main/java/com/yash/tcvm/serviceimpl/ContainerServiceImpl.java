package com.yash.tcvm.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import com.yash.tcvm.enumeration.Ingredient;
import com.yash.tcvm.model.Container;
import com.yash.tcvm.service.ContainerService;

public class ContainerServiceImpl implements ContainerService {

	private List<Container> containers;

	public ContainerServiceImpl() {
		containers = new ArrayList<Container>();

		containers.add(new Container(Ingredient.MILK, 10000, 10000));
		containers.add(new Container(Ingredient.TEA, 2000, 2000));
		containers.add(new Container(Ingredient.WATER, 15000, 15000));
		containers.add(new Container(Ingredient.SUGAR, 8000, 8000));
		containers.add(new Container(Ingredient.COFFEE, 2000, 2000));
		
	}

	public Container getContainerByIngredient(Ingredient ingredient) {
		Container selectedContainer = null;
		for (Container container : containers) {
			if (container.getIngredient() == ingredient) {
				selectedContainer = container;
				break;
			}
		}
		return selectedContainer;
	}

	public List<Container> getContainers() {
		return containers;
	}
}

package com.yash.tcvm.exception;

public class QuantityNotSpecifiedException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public QuantityNotSpecifiedException(String errorMessage) {
		super(errorMessage);
	}
}

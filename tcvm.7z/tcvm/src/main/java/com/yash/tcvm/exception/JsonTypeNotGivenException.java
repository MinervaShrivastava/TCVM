package com.yash.tcvm.exception;

public class JsonTypeNotGivenException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public JsonTypeNotGivenException(String errorMessage) {
		super(errorMessage);
	}
}
